tinyMCE.addI18n('is.searchreplace_dlg',{
searchnext_desc:"Finna aftur",
notfound:"Leitinni er loki\u00F0. Leitarstrengurinn fannst ekki.",
search_title:"Finna",
replace_title:"Finna/Skipta \u00FAt",
allreplaced:"\u00D6llum ni\u00F0urst\u00F6\u00F0um leitar var skipt \u00FAt.",
findwhat:"Finna hva\u00F0",
replacewith:"Skipta \u00FAt me\u00F0",
direction:"\u00C1tt",
up:"Upp",
down:"Ni\u00F0ur",
mcase:"Match case",
findnext:"Finna n\u00E6sta",
replace:"Skipta \u00FAt",
replaceall:"Skipta \u00FAt \u00F6llu"
});