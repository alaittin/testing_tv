tinyMCE.addI18n('sq.searchreplace_dlg',{
searchnext_desc:"K\u00EBrko p\u00EBrs\u00EBri",
notfound:"K\u00EBrkimi p\u00EBrfundoi dhe nuk ktheu asnj\u00EB rezultat.",
search_title:"K\u00EBrko",
replace_title:"K\u00EBrko/Z\u00EBvend\u00EBso",
allreplaced:"T\u00EB gjitha tekstet e gjetura u z\u00EBvend\u00EBsuan.",
findwhat:"K\u00EBrko p\u00EBr",
replacewith:"Z\u00EBvend\u00EBso me",
direction:"Drejtimi",
up:"Lart",
down:"Posht\u00EB",
mcase:"P\u00EBrshtat madh\u00EBsin\u00EB e g\u00EBrm\u00EBs",
findnext:"K\u00EBrko tjetr\u00EBn",
replace:"Z\u00EBvend\u00EBso",
replaceall:"Z\u00EBv. t\u00EB gjitha"
});