tinyMCE.addI18n('sk.searchreplace_dlg',{
searchnext_desc:"H\u013Eada\u0165 \u010Falej",
notfound:"H\u013Eadanie bolo dokon\u010Den\u00E9. H\u013Eadan\u00FD text nebol n\u00E1jden\u00FD.",
search_title:"H\u013Eada\u0165",
replace_title:"H\u013Eada\u0165 a nahradi\u0165",
allreplaced:"V\u0161etky v\u00FDskyty boli nahraden\u00E9.",
findwhat:"H\u013Eada\u0165 \u010Do",
replacewith:"Nahradi\u0165 \u010D\u00EDm",
direction:"Smer",
up:"Nahor",
down:"Nadol",
mcase:"Rozli\u0161ova\u0165 ve\u013Ekos\u0165",
findnext:"H\u013Eada\u0165 dalej",
replace:"Nahradi\u0165",
replaceall:"Nahradi\u0165 v\u0161etko"
});