tinyMCE.addI18n('bs.searchreplace_dlg',{
searchnext_desc:"Prona\u0111i opet",
notfound:"Pretra\u017Eivanje je zavr\u0161eno. Tra\u017Eeni tekst nije prona\u0111en.",
search_title:"Prona\u0111i",
replace_title:"Prona\u0111i/Zamijeni",
allreplaced:"Sva pojavljivanja tra\u017Eenog teksta su zamijenjena.",
findwhat:"Prona\u0111i tekst",
replacewith:"Zamijeni sa",
direction:"Smjer",
up:"Gore",
down:"Dolje",
mcase:"Match case",
findnext:"Prona\u0111i sljede\u0107e",
replace:"Zamijeni",
replaceall:"Zamijeni sve"
});