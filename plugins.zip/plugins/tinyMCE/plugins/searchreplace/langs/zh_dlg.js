tinyMCE.addI18n('zh.searchreplace_dlg',{
searchnext_desc:"\u518D\u6B21\u641C\u5BFB",
notfound:"\u641C\u5BFB\u5DF2\u5B8C\u6210!\u627E\u4E0D\u5230\u4EFB\u4F55\u76EE\u6807\u3002 ",
search_title:"\u641C\u5BFB",
replace_title:"\u641C\u5BFB/\u53D6\u4EE3",
allreplaced:"\u5DF2\u53D6\u4EE3\u6240\u6709\u5339\u914D\u7684\u7B26\u4E32.",
findwhat:"\u641C\u5BFB\u76EE\u6807",
replacewith:"\u53D6\u4EE3\u4E3A",
direction:"\u65B9\u5411",
up:"\u5411\u4E0A",
down:"\u5411\u4E0B",
mcase:"\u5927\u5C0F\u5199\u5339\u914D",
findnext:"\u4E0B\u4E00\u4E2A",
replace:"\u53D6\u4EE3",
replaceall:"\u53D6\u4EE3\u5168\u90E8"
});