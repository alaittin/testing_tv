tinyMCE.addI18n('fr.searchreplace_dlg',{
searchnext_desc:"Suivant",
notfound:"La recherche est termin\u00E9e. La cha\u00EEne recherch\u00E9e n'a pas \u00E9t\u00E9 trouv\u00E9e.",
search_title:"Rechercher",
replace_title:"Rechercher / remplacer",
allreplaced:"Toutes les occurrences de la cha\u00EEne recherch\u00E9e ont \u00E9t\u00E9 remplac\u00E9es.",
findwhat:"Rechercher ceci",
replacewith:"Remplacer par",
direction:"Direction",
up:"Vers le haut",
down:"Vers le bas",
mcase:"Sensible \u00E0 la casse",
findnext:"Rechercher le suivant",
replace:"Remplacer",
replaceall:"Tout remplacer"
});