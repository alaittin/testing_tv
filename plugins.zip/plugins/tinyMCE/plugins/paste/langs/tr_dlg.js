tinyMCE.addI18n('tr.paste_dlg',{
text_title:"Pencereye metin yap\u0131\u015Ft\u0131rmak i\u00E7in klavyeden CTRL+V i kullan\u0131n.",
text_linebreaks:"Sat\u0131r kesmelerini tut",
word_title:"Pencereye metin yap\u0131\u015Ft\u0131rmak i\u00E7in klavyeden CTRL+V i kullan\u0131n."
});