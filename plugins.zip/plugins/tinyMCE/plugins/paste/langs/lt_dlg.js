tinyMCE.addI18n('lt.paste_dlg',{
text_title:"Naudokite CTRL+V tekstui \u012Fd\u0117ti \u012F \u0161\u012F lang\u0105.",
text_linebreaks:"Palikti eilu\u010Di\u0173 l\u016B\u017Eius",
word_title:"Naudokite CTRL+V tekstui \u012Fd\u0117ti \u012F \u0161\u012F lang\u0105."
});