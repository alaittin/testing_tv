/* SyntaxHighlighter 2.0.296 (C) 2004-2009 Alex Gorbatchev */
SyntaxHighlighter.config.clipboardSwf = "plugins/highlighter/scripts/clipboard.swf";
SyntaxHighlighter.all();